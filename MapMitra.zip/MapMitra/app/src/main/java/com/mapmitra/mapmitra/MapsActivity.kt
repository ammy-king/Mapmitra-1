package com.example.afinal

import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentSender.SendIntentException
import android.location.Location
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.LocationSettingsResponse
import com.google.android.gms.location.SettingsClient
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.AutocompletePrediction
import com.google.android.libraries.places.api.model.AutocompleteSessionToken
import com.google.android.libraries.places.api.net.PlacesClient
import com.mapmitra.mapmitra.R

class MapActivity : AppCompatActivity(), OnMapReadyCallback {
    private var mMap: GoogleMap? = null
    private var mFusedLocationProviderClient: FusedLocationProviderClient? = null
    private var placesClient: PlacesClient? = null
    private val predictionList: List<AutocompletePrediction>? = null
    private var mLastKnownLocation: Location? = null
    private var locationCallback: LocationCallback? = null
    private var mapView: View? = null
    private val btnFind: Button? = null
    private val DEFAULT_ZOOM = 25f
    var ltln = arrayOf(
        doubleArrayOf(21.016811, 75.537247),
        doubleArrayOf(21.015557, 75.502517),
        doubleArrayOf(21.014938, 75.502350),
        doubleArrayOf(21.017321, 75.514200),
        doubleArrayOf(21.195488, 76.138559)
    )
    var title = arrayOf(
        "Gujral Petrol Pump",
        "Ganesh Temple,SSBT",
        "SAGAR Xerox Center,SSBT",
        "Podar International",
        "Current"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)
        val mapFragment =
            supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment!!.getMapAsync(this)
        mapView = mapFragment.view
        mFusedLocationProviderClient =
            LocationServices.getFusedLocationProviderClient(this@MapActivity)
        Places.initialize(this@MapActivity, getString(R.string.google_map_api_key))
        placesClient = Places.createClient(this)
        val token: AutocompleteSessionToken = AutocompleteSessionToken.newInstance()
    }

    @SuppressLint("MissingPermission")
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap!!.isMyLocationEnabled = true
        mMap!!.mapType = GoogleMap.MAP_TYPE_HYBRID
        mMap!!.isTrafficEnabled = true
        mMap!!.uiSettings.isMyLocationButtonEnabled = true
        for (i in ltln.indices) {
            val marker = mMap!!.addMarker(
                MarkerOptions()
                    .position(
                        LatLng(
                            ltln[i][0],
                            ltln[i][1]
                        )
                    )
                    .title(title[i])
                    .alpha(0.5.toFloat())
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.no_entry))
            )
        }
        if (mapView != null && mapView!!.findViewById<View?>("1".toInt()) != null) {
            val locationButton =
                (mapView!!.findViewById<View>("1".toInt())
                    .parent as View).findViewById<View>("2".toInt())
            val layoutParams =
                locationButton.layoutParams as RelativeLayout.LayoutParams
            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0)
            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE)
            layoutParams.setMargins(0, 0, 40, 180)
        }

        // check if GPS is enabled or not & then request user to enable it
        val locationRequest: LocationRequest = LocationRequest.create()
        locationRequest.setInterval(10000)
        locationRequest.setFastestInterval(5000)
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
        val builder: LocationSettingsRequest.Builder = Builder().addLocationRequest(locationRequest)
        val settingsClient: SettingsClient = LocationServices.getSettingsClient(this@MapActivity)
        val task: Task<LocationSettingsResponse> =
            settingsClient.checkLocationSettings(builder.build())
        task.addOnSuccessListener(
            this@MapActivity
        ) { deviceLocation }
        task.addOnFailureListener(
            this@MapActivity
        ) { e ->
            if (e is ResolvableApiException) {
                try {
                    e.startResolutionForResult(this@MapActivity, 51)
                } catch (e1: SendIntentException) {
                    e1.printStackTrace()
                }
            }
        }
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 51) {
            if (resultCode == Activity.RESULT_OK) {
                deviceLocation
                val latt = mLastKnownLocation!!.latitude
                val lon = mLastKnownLocation!!.longitude
                checkObstacles(ltln, latt, lon)
            }
        }
    }

    private fun addNotification() {
        val build: NotificationCompat.Builder
        build = NotificationCompat.Builder(this)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Notifications Example")
            .setContentText("This is a test notification")
        val notificationIntent = Intent(this, MapActivity::class.java)
        val contentIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_UPDATE_CURRENT
        )
        build.setContentIntent(contentIntent)

        // Add as notification
        val manager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(0, build.build())
    }

    fun checkObstacles(
        ltln: Array<DoubleArray>,
        latt: Double,
        lon: Double
    ) {
        val alertDialogBuilder =
            AlertDialog.Builder(this)
        alertDialogBuilder.setMessage("Obstacle at 50 mtrs ahead....")
        alertDialogBuilder.setPositiveButton("Ok",
            DialogInterface.OnClickListener { arg0, arg1 ->
                Toast.makeText(this@MapActivity, "Thank You!!", Toast.LENGTH_LONG).show()
                return@OnClickListener
            })
            .setNegativeButton("Cancel",
                DialogInterface.OnClickListener { dialog, which -> return@OnClickListener })
        val alertDialog = alertDialogBuilder.create()
        for (i in ltln.indices) {
            if (ltln[i][0] - latt <= 0.000500) {
                alertDialog.show()
                addNotification()
            }
        }
    }

    @get:SuppressLint("MissingPermission")
    private val deviceLocation: Unit
        private get() {
            mFusedLocationProviderClient.getLastLocation()
                .addOnCompleteListener(OnCompleteListener<Location?> { task ->
                    if (task.isSuccessful) {
                        mLastKnownLocation = task.result
                        if (mLastKnownLocation != null) {
                            mMap!!.moveCamera(
                                CameraUpdateFactory.newLatLngZoom(
                                    LatLng(
                                        mLastKnownLocation!!.latitude,
                                        mLastKnownLocation!!.longitude
                                    ), DEFAULT_ZOOM
                                )
                            )
                        } else {
                            val locationRequest: LocationRequest = LocationRequest.create()
                            locationRequest.setInterval(10000)
                            locationRequest.setFastestInterval(5000)
                            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                            locationCallback = object : LocationCallback() {
                                fun onLocationResult(locationResult: LocationResult?) {
                                    super.onLocationResult(locationResult)
                                    if (locationResult == null) {
                                        return
                                    }
                                    mLastKnownLocation = locationResult.getLastLocation()
                                    mMap!!.moveCamera(
                                        CameraUpdateFactory.newLatLngZoom(
                                            LatLng(
                                                mLastKnownLocation!!.latitude,
                                                mLastKnownLocation!!.longitude
                                            ), DEFAULT_ZOOM
                                        )
                                    )
                                    mFusedLocationProviderClient.removeLocationUpdates(
                                        locationCallback
                                    )
                                }
                            }
                            mFusedLocationProviderClient.requestLocationUpdates(
                                locationRequest,
                                locationCallback,
                                null
                            )
                        }
                    } else {
                        Toast.makeText(
                            this@MapActivity,
                            "unable to get Last Location",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                })
        }
}